<?php
namespace Mandala\AdobeGateway\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const XML_PATH_PAYMENT = 'payment/mandala_gateway/';

    public function getConfig($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT . $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function isActive($storeId = null)
    {
        return (bool)$this->getConfig('active', $storeId);
    }
}
