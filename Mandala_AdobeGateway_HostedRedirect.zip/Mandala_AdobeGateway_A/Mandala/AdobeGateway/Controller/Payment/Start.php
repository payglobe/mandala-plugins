<?php
namespace Mandala\AdobeGateway\Controller\Payment;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Model\OrderFactory;
use Mandala\AdobeGateway\Helper\Data as MandalaHelper;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Controller\Result\RedirectFactory;

class Start extends Action
{
    protected $checkoutSession;
    protected $orderFactory;
    protected $helper;
    protected $curl;
    protected $resultRedirectFactory;

    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        OrderFactory $orderFactory,
        MandalaHelper $helper,
        Curl $curl,
        RedirectFactory $resultRedirectFactory
    ) {
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->curl = $curl;
        $this->resultRedirectFactory = $resultRedirectFactory;
    }

    public function execute()
    {
        $order = $this->checkoutSession->getLastRealOrder();
        if (!$order || !$order->getId()) {
            $this->messageManager->addErrorMessage(__('Ordine non trovato.'));
            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }

        try {
            $apiKey = $this->helper->getConfig('api_key', $order->getStoreId());
            $apiBase = rtrim($this->helper->getConfig('api_base', $order->getStoreId()) ?: 'https://api.mandala-gateway.com', '/');

            $amount = (int) round($order->getGrandTotal() * 100);
            $currency = strtolower($order->getOrderCurrencyCode());

            $payload = [
                'amount'      => $amount,
                'currency'    => $currency,
                'confirm'     => true,
                'confirmation_method' => 'automatic',
                'metadata'    => [
                    'order_id' => $order->getIncrementId(),
                    'magento_order_id' => $order->getId()
                ],
                'return_url'  => $this->_url->getUrl('mandala/payment/callback', ['_secure' => true])
            ];

            $this->curl->setHeaders([
                'Authorization' => 'Bearer ' . $apiKey
            ]);
            $this->curl->post($apiBase . '/v1/payment_intents', $payload);

            $status = $this->curl->getStatus();
            $body = $this->curl->getBody();
            $data = json_decode($body, true);

            if ($status >= 400 || !$data) {
                throw new \Exception(isset($data['error']['message']) ? $data['error']['message'] : 'Errore API Mandala');
            }

            if (!empty($data['next_action']['redirect_to_url']['url'])) {
                $redirectUrl = $data['next_action']['redirect_to_url']['url'];
            } elseif (!empty($data['hosted_url'])) {
                $redirectUrl = $data['hosted_url'];
            } else {
                throw new \Exception('Nessun URL di redirect restituito da Mandala.');
            }

            $order->addCommentToStatusHistory(__('Reindirizzamento a Mandala per il pagamento.'));
            $order->save();

            return $this->resultRedirectFactory->create()->setUrl($redirectUrl);

        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Errore Mandala: %1', $e->getMessage()));
            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }
    }
}
