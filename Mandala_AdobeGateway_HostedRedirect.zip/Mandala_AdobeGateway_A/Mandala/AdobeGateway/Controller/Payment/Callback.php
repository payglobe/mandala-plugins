<?php
namespace Mandala\AdobeGateway\Controller\Payment;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Model\OrderFactory;

class Callback extends Action
{
    protected $checkoutSession;
    protected $orderFactory;

    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        OrderFactory $orderFactory
    ) {
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
    }

    public function execute()
    {
        // In un flusso hosted, l'esito finale arriverà via webhook.
        // Qui possiamo semplicemente rimandare il cliente alla pagina di successo.
        return $this->_redirect('checkout/onepage/success');
    }
}
