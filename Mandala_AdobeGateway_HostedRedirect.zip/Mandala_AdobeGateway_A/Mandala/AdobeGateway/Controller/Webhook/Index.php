<?php
namespace Mandala\AdobeGateway\Controller\Webhook;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Mandala\AdobeGateway\Helper\Data as MandalaHelper;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Framework\Webapi\Rest\Response as RestResponse;

class Index extends Action
{
    protected $helper;
    protected $orderFactory;
    protected $orderRepository;

    public function __construct(
        Context $context,
        MandalaHelper $helper,
        OrderFactory $orderFactory,
        OrderRepositoryInterface $orderRepository
    ) {
        parent::__construct($context);
        $this->helper = $helper;
        $this->orderFactory = $orderFactory;
        $this->orderRepository = $orderRepository;
    }

    public function execute()
    {
        $request = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_PAYGLOBE_SIGNATURE'] ?? '';

        $secret = $this->helper->getConfig('webhook_secret');
        if (!$secret) {
            http_response_code(400);
            echo 'Webhook secret non configurato';
            return;
        }

        $expected = hash_hmac('sha256', $request, $secret);
        if (!hash_equals($expected, $signature)) {
            http_response_code(400);
            echo 'Firma non valida';
            return;
        }

        $event = json_decode($request, true);
        if (!$event || empty($event['type'])) {
            http_response_code(400);
            echo 'Payload non valido';
            return;
        }

        switch ($event['type']) {
            case 'payment_intent.succeeded':
                $this->handlePaymentSucceeded($event['data']['object'] ?? []);
                break;
            case 'payment_intent.payment_failed':
                $this->handlePaymentFailed($event['data']['object'] ?? []);
                break;
        }

        http_response_code(200);
        echo 'OK';
    }

    protected function handlePaymentSucceeded(array $intent)
    {
        if (empty($intent['metadata']['magento_order_id'])) {
            return;
        }
        $orderId = (int)$intent['metadata']['magento_order_id'];
        /** @var Order $order */
        $order = $this->orderRepository->get($orderId);
        if (!$order || $order->getState() === Order::STATE_PROCESSING) {
            return;
        }

        $order->setState(Order::STATE_PROCESSING)->setStatus(Order::STATE_PROCESSING);
        $order->addCommentToStatusHistory(__('Pagamento Mandala riuscito (PI %1).', $intent['id'] ?? ''));
        $this->orderRepository->save($order);
    }

    protected function handlePaymentFailed(array $intent)
    {
        if (empty($intent['metadata']['magento_order_id'])) {
            return;
        }
        $orderId = (int)$intent['metadata']['magento_order_id'];
        /** @var Order $order */
        $order = $this->orderRepository->get($orderId);
        if (!$order) {
            return;
        }
        $order->addCommentToStatusHistory(__('Pagamento Mandala fallito (PI %1).', $intent['id'] ?? ''));
        $this->orderRepository->save($order);
    }
}
