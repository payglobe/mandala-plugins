<?php
namespace Mandala\AdobeGateway\Model;

use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Model\OrderFactory;
use Magento\Framework\UrlInterface;

class Payment extends AbstractMethod
{
    protected $_code = 'mandala_gateway';
    protected $_isGateway = true;
    protected $_canUseInternal = false;
    protected $_canUseCheckout = true;
    protected $_canCapture = false;
    protected $_canRefund = false;
    protected $_canVoid = false;
    protected $_isInitializeNeeded = false;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        UrlInterface $urlBuilder,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            null,
            null,
            $data
        );
        $this->urlBuilder = $urlBuilder;
    }

    public function getOrderPlaceRedirectUrl()
    {
        return $this->urlBuilder->getUrl('mandala/payment/start', ['_secure' => true]);
    }
}
