<?php
namespace Mandala\AdobeGateway\Model;
class Payment extends \Magento\Payment\Model\Method\AbstractMethod { protected $_code='mandala_gateway'; }
