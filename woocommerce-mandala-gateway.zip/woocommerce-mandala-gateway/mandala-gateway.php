<?php
/**
 * Plugin Name: Mandala Gateway for WooCommerce
 * Plugin URI: https://api.payglobe.it/mandala/
 * Description: Gateway di pagamento Mandala API-compatibile Stripe per WooCommerce.
 * Author: PayGlobe S.r.l.
 * Author URI: https://www.payglobe.it/
 * Version: 1.0.0
 * License: GPLv3
 * Text Domain: mandala-gateway
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'mandala_wc_gateway_init', 11);

function mandala_wc_gateway_init() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    define('MANDALA_WC_GATEWAY_VERSION', '1.0.0');
    define('MANDALA_WC_GATEWAY_DIR', plugin_dir_path(__FILE__));
    define('MANDALA_WC_GATEWAY_URL', plugin_dir_url(__FILE__));

    require_once MANDALA_WC_GATEWAY_DIR . 'includes/class-wc-gateway-mandala-api.php';
    require_once MANDALA_WC_GATEWAY_DIR . 'includes/class-wc-gateway-mandala-webhook-handler.php';
    require_once MANDALA_WC_GATEWAY_DIR . 'includes/class-wc-gateway-mandala-tokens.php';
    require_once MANDALA_WC_GATEWAY_DIR . 'includes/class-wc-gateway-mandala.php';

    add_filter('woocommerce_payment_gateways', function ($methods) {
        $methods[] = 'WC_Gateway_Mandala';
        return $methods;
    });

    add_action('init', function () {
        add_rewrite_rule('^wc-api/wc_gateway_mandala/?', 'index.php?wc-api=wc_gateway_mandala', 'top');
    });

    add_action('woocommerce_api_wc_gateway_mandala', ['WC_Gateway_Mandala_Webhook_Handler', 'handle']);
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=mandala');
    $settings_link = '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings', 'mandala-gateway') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
});
