<?php
// Cleanup opzionale in disinstallazione plugin
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Qui potresti rimuovere meta utente/tokens se vuoi.
