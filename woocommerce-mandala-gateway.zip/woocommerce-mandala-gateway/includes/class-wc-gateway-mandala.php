<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_Mandala extends WC_Payment_Gateway_CC {

    public function __construct() {
        $this->id                 = 'mandala';
        $this->method_title       = __('Mandala Gateway', 'mandala-gateway');
        $this->method_description = __('Processa pagamenti tramite Mandala (API compatibili Stripe).', 'mandala-gateway');
        $this->has_fields         = true;

        $this->supports = [
            'products',
            'tokenization',
            'refunds',
        ];

        $this->init_form_fields();
        $this->init_settings();

        $this->enabled        = $this->get_option('enabled');
        $this->title          = $this->get_option('title');
        $this->description    = $this->get_option('description');
        $this->secret_key     = $this->get_option('secret_key');
        $this->api_base       = $this->get_option('api_base', 'https://api.mandala-gateway.com');
        $this->webhook_secret = $this->get_option('webhook_secret');

        $this->api = new WC_Gateway_Mandala_API($this->secret_key, $this->api_base);

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'   => __('Abilita/Disabilita', 'mandala-gateway'),
                'type'    => 'checkbox',
                'label'   => __('Abilita Mandala Gateway', 'mandala-gateway'),
                'default' => 'yes',
            ],
            'title' => [
                'title'       => __('Titolo', 'mandala-gateway'),
                'type'        => 'text',
                'default'     => __('Paga con carta (Mandala)', 'mandala-gateway'),
            ],
            'description' => [
                'title'       => __('Descrizione', 'mandala-gateway'),
                'type'        => 'textarea',
                'default'     => __('Pagamenti elaborati in sicurezza tramite Mandala.', 'mandala-gateway'),
            ],
            'secret_key' => [
                'title'       => __('Mandala Secret Key (sk_*)', 'mandala-gateway'),
                'type'        => 'password',
            ],
            'api_base' => [
                'title'       => __('API Base URL', 'mandala-gateway'),
                'type'        => 'text',
                'default'     => 'https://api.mandala-gateway.com',
            ],
            'webhook_secret' => [
                'title'       => __('Webhook signing secret', 'mandala-gateway'),
                'type'        => 'password',
                'description' => __('Usato per verificare la firma X-PayGlobe-Signature.', 'mandala-gateway'),
            ],
        ];
    }

    public function payment_fields() {
        if ($this->description) {
            echo '<p>' . wp_kses_post($this->description) . '</p>';
        }

        parent::payment_fields();
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        try {
            $amount   = intval(round($order->get_total() * 100));
            $currency = strtolower($order->get_currency());

            $user_id       = $order->get_user_id();
            $mandala_cust  = $user_id ? WC_Gateway_Mandala_Tokens::get_customer_id($user_id) : null;

            if ($user_id && !$mandala_cust) {
                $customer = $this->api->create_customer($order->get_billing_email(), [
                    'woocommerce_user_id' => $user_id,
                ]);
                $mandala_cust = $customer['id'];
                WC_Gateway_Mandala_Tokens::set_customer_id($user_id, $mandala_cust);
            }

            $intent_params = [
                'amount'               => $amount,
                'currency'             => $currency,
                'confirmation_method'  => 'automatic',
                'confirm'              => true,
                'metadata'             => [
                    'order_id' => $order_id,
                    'site_url' => get_site_url(),
                ],
            ];

            $token_id = isset($_POST['wc-' . $this->id . '-payment-token']) ? wc_clean(wp_unslash($_POST['wc-' . $this->id . '-payment-token'])) : '';

            if ($token_id && 'new' !== $token_id) {
                $wc_token = WC_Payment_Tokens::get($token_id);
                if ($wc_token && $wc_token->get_user_id() === $user_id) {
                    $intent_params['payment_method'] = $wc_token->get_token();
                    $intent_params['customer']       = $mandala_cust;
                }
            } else {
                $payment_method_id = isset($_POST['mandala_payment_method_id']) ? wc_clean(wp_unslash($_POST['mandala_payment_method_id'])) : '';
                if (!$payment_method_id) {
                    throw new Exception(__('Nessun metodo di pagamento Mandala fornito.', 'mandala-gateway'));
                }
                $intent_params['payment_method'] = $payment_method_id;
                if ($mandala_cust) {
                    $intent_params['customer'] = $mandala_cust;
                }

                if ($this->supports('tokenization') && !empty($_POST['wc-' . $this->id . '-new-payment-method']) && $user_id) {
                    $pm = $this->api->retrieve_payment_method($payment_method_id);
                    WC_Gateway_Mandala_Tokens::add_token(
                        $user_id,
                        $payment_method_id,
                        $pm['card']['brand'] ?? 'card',
                        $pm['card']['last4'] ?? '0000',
                        $pm['card']['exp_month'] ?? '01',
                        $pm['card']['exp_year'] ?? '2099'
                    );
                }
            }

            $intent = $this->api->create_payment_intent($intent_params);

            if (isset($intent['status']) && $intent['status'] === 'requires_action' && !empty($intent['next_action']['redirect_to_url']['url'])) {
                $order->update_meta_data('_mandala_payment_intent_id', $intent['id']);
                $order->save();

                return [
                    'result'   => 'success',
                    'redirect' => $intent['next_action']['redirect_to_url']['url'],
                ];
            }

            if (isset($intent['status']) && in_array($intent['status'], ['succeeded', 'requires_capture'], true)) {
                $order->payment_complete($intent['id']);
                $order->add_order_note(sprintf('Pagamento Mandala completato (PI %s).', $intent['id']));

                return [
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                ];
            }

            $message = isset($intent['error']['message']) ? $intent['error']['message'] : 'Errore sconosciuto';
            wc_add_notice(__('Pagamento non riuscito: ', 'mandala-gateway') . $message, 'error');
            return ['result' => 'failure'];

        } catch (Exception $e) {
            wc_add_notice(__('Errore Mandala: ', 'mandala-gateway') . $e->getMessage(), 'error');
            return ['result' => 'failure'];
        }
    }

    public function process_refund($order_id, $amount = null, $reason = '') {
        // TODO: implementare /v1/refunds Mandala se disponibile
        return false;
    }
}
