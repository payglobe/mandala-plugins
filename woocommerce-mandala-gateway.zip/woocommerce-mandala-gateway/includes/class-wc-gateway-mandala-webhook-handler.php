<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_Mandala_Webhook_Handler {

    public static function handle() {
        $payload  = file_get_contents('php://input');
        $sig      = isset($_SERVER['HTTP_X_PAYGLOBE_SIGNATURE']) ? $_SERVER['HTTP_X_PAYGLOBE_SIGNATURE'] : '';
        $secret   = get_option('woocommerce_mandala_webhook_secret', '');

        if (empty($secret)) {
            status_header(400);
            echo 'Webhook secret not configured';
            exit;
        }

        if (!self::verify_signature($payload, $sig, $secret)) {
            status_header(400);
            echo 'Invalid signature';
            exit;
        }

        $event = json_decode($payload, true);

        if (empty($event['type'])) {
            status_header(400);
            echo 'Invalid payload';
            exit;
        }

        self::process_event($event);
        status_header(200);
        echo 'OK';
        exit;
    }

    protected static function verify_signature($payload, $signature, $secret) {
        $expected = hash_hmac('sha256', $payload, $secret);
        return hash_equals($expected, $signature);
    }

    protected static function process_event($event) {
        switch ($event['type']) {
            case 'payment_intent.succeeded':
                $intent = $event['data']['object'];
                self::mark_order_paid($intent);
                break;

            case 'payment_intent.payment_failed':
                // TODO: gestire eventuali log
                break;
        }
    }

    protected static function mark_order_paid($intent) {
        if (empty($intent['metadata']['order_id'])) {
            return;
        }

        $order_id = intval($intent['metadata']['order_id']);
        $order    = wc_get_order($order_id);

        if (!$order || $order->is_paid()) {
            return;
        }

        $order->payment_complete($intent['id']);
        $order->add_order_note(sprintf('Pagamento Mandala completato (PI %s).', $intent['id']));
    }
}
