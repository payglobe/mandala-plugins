<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_Mandala_Tokens {

    const USER_META_CUSTOMER_ID = '_mandala_customer_id';

    public static function get_customer_id($user_id) {
        return get_user_meta($user_id, self::USER_META_CUSTOMER_ID, true);
    }

    public static function set_customer_id($user_id, $customer_id) {
        update_user_meta($user_id, self::USER_META_CUSTOMER_ID, $customer_id);
    }

    public static function add_token($user_id, $payment_method_id, $brand, $last4, $exp_month, $exp_year) {
        $token = new WC_Payment_Token_CC();
        $token->set_token($payment_method_id);
        $token->set_gateway_id('mandala');
        $token->set_card_type($brand);
        $token->set_last4($last4);
        $token->set_expiry_month($exp_month);
        $token->set_expiry_year($exp_year);
        $token->set_user_id($user_id);
        $token->save();
        return $token;
    }
}
