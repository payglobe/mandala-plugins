<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_Mandala_API {

    protected $secret_key;
    protected $api_base;

    public function __construct($secret_key, $api_base = 'https://api.mandala-gateway.com') {
        $this->secret_key = $secret_key;
        $this->api_base   = rtrim($api_base, '/');
    }

    protected function request($method, $path, $body = []) {
        $url = $this->api_base . $path;

        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->secret_key,
            ],
            'timeout' => 60,
        ];

        if (!empty($body)) {
            $args['body'] = $body;
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            throw new Exception('Mandala API connection error: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw  = wp_remote_retrieve_body($response);
        $data = json_decode($raw, true);

        if ($code >= 400) {
            $message = isset($data['error']['message']) ? $data['error']['message'] : 'Unknown error';
            throw new Exception('Mandala API error (' . $code . '): ' . $message);
        }

        return $data;
    }

    public function create_customer($email, $metadata = []) {
        return $this->request('POST', '/v1/customers', [
            'email'    => $email,
            'metadata' => $metadata,
        ]);
    }

    public function attach_payment_method($customer_id, $payment_method_id) {
        return $this->request('POST', '/v1/payment_methods/' . $payment_method_id . '/attach', [
            'customer' => $customer_id,
        ]);
    }

    public function create_payment_intent($params) {
        return $this->request('POST', '/v1/payment_intents', $params);
    }

    public function retrieve_payment_intent($id) {
        return $this->request('GET', '/v1/payment_intents/' . $id);
    }

    public function retrieve_payment_method($id) {
        return $this->request('GET', '/v1/payment_methods/' . $id);
    }
}
