# Mandala Gateway for WooCommerce

Gateway di pagamento Mandala **Stripe-API compatible** per WooCommerce.

> Mandala / PayGlobe non sono affiliati, approvati o sponsorizzati da Stripe, Inc.  
> Stripe è un marchio registrato di Stripe, Inc.

## Funzionalità

- Pagamenti con Mandala Payment Intents
- Endpoint API compatibili con Stripe (`/v1/payment_intents`, `/v1/customers`, ecc.)
- Carte salvate (tokenization via WooCommerce Payment Tokens)
- Webhook con `X-PayGlobe-Signature`
- Supporto 3D Secure tramite `requires_action` + redirect
- Compatibile con WooCommerce 6.x/7.x/8.x

## Installazione

1. Copia la cartella `woocommerce-mandala-gateway` dentro `wp-content/plugins/`.
2. Attiva **Mandala Gateway for WooCommerce** da Plugins.
3. Vai su **WooCommerce → Settings → Payments → Mandala**.
4. Inserisci:
   - `Mandala Secret Key (sk_...)`
   - `Webhook signing secret`
   - (opzionale) API base custom per sandbox.

## Licenza

Questo plugin è rilasciato sotto licenza **GPLv3**.  
Fork concettuale del plugin WooCommerce Stripe Gateway (GPLv3).
